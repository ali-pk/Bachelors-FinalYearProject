﻿using Nelibur.ObjectMapper;
using Spire.Doc;
using Spire.Doc.Documents;
using Spire.Doc.Fields;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using WordDocumentFormatting.BusinessLayer.Common;
using WordDocumentFormatting.DataAccessLayer;
using WordDocumentFormatting.DataAccessLayer.Model;

namespace WordDocumentFormatting.BusinessLayer
{
    public interface ITitlePageService
    {
        public (ParagraphValidationRes, int) TitlePageValidation(Section section, int startIndex);
    }
    public class TitlePageService : ITitlePageService
    {
        //DatabaseManager databaseManager= new DatabaseManager();
        private readonly DatabaseManager _context;
        private readonly ITitlePageParagraphValidation _paragraphValidation;
        private readonly IGeneralParagraphValidation _generalParagraphValidation;

        public TitlePageService(DatabaseManager context, ITitlePageParagraphValidation paragraphValidation, IGeneralParagraphValidation generalParagraphValidation)
        {
            _context = context;
            _paragraphValidation = paragraphValidation;
            _generalParagraphValidation = generalParagraphValidation;
        }

        public (ParagraphValidationRes, int) TitlePageValidation(Section section, int startIndex)
        {
            bool validationResult = true;
            List<string> validationMessage = new List<string>();
            foreach (var item in _context.TitlePages.OrderBy(x => x.SectionOrder))
            {
                
                var validationList = TinyMapper.Map<List<ValidationTextDTO>>(_context.ValidationText.Where(x => x.ReferenceID.ID == item.ID).ToList());
                var res = _validationParagraph(section, startIndex, item, validationList);
                startIndex = res.Item2;
                validationResult = res.Item1.ValidationResult;
                if (res.Item1.ValidationResult == false)
                {
                    validationMessage.AddRange(res.Item1.ValidationMessage);
                    return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
                }
                if (res.Item1.ValidationResult)
                {
                    validationMessage.Add($"All defined validations are clear in section \"{item.SectionName}\"");
                }
            }
            return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
        }

        private (ParagraphValidationRes, int) _validationParagraph(Section section, int startIndex, TitlePage titlePage,List<ValidationTextDTO> validationText)
        {
            ParagraphValidationRes validationRes = new ParagraphValidationRes();
            List<string> studentName = new List<string>();

            foreach (Paragraph paragraph in section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).Skip(startIndex))
            {
                GeneralClass generalClass = TinyMapper.Map<GeneralClass>(titlePage);
                validationRes = _generalParagraphValidation.GetGeneralParagraphValidation(paragraph, generalClass, validationText);
                if(titlePage.SectionName.Equals("StudentName"))
                {
                    studentName.Add(paragraph.Text);
                }
                if (validationRes.ValidationResult)
                {
                    validationRes = _paragraphValidation.GetTitlePageParagraphValidation(paragraph, titlePage);
                }
                startIndex++;
                if (string.IsNullOrEmpty(titlePage.StopLineText) || !validationRes.ValidationResult)
                {
                    break;
                }
                if (titlePage.StopLineText.ToLower().Equals(section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).ToArray()[startIndex].Text.ToLower()))
                {
                    if(titlePage.SectionName.Equals("StudentName"))
                    {
                        DataClass.StudentName = studentName;
                    }
                    break;
                }
            }


            return (validationRes, startIndex);
        }
    }
}
