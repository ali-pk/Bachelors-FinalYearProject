﻿using Nelibur.ObjectMapper;
using Spire.Doc;
using Spire.Doc.Documents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordDocumentFormatting.BusinessLayer.Common;
using WordDocumentFormatting.DataAccessLayer;
using WordDocumentFormatting.DataAccessLayer.Model;

namespace WordDocumentFormatting.BusinessLayer
{
    public interface IDeclarationPageService
    {
        public (ParagraphValidationRes, int) DelarationPageValidation(Section section, int startIndex);
    }
    public class DeclarationPageService:IDeclarationPageService
    {
        private readonly DatabaseManager _context;
        //private readonly IGeneralParagraphValidation _paragraphValidation;
        private readonly IGeneralParagraphValidation _generalParagraphValidation;

        public DeclarationPageService(DatabaseManager context, IGeneralParagraphValidation generalParagraphValidation)
        {
            _context = context;
            _generalParagraphValidation = generalParagraphValidation;
        }

        public (ParagraphValidationRes, int) DelarationPageValidation(Section section, int startIndex)
        {
            bool validationResult = true;
            List<string> validationMessage = new List<string>();
            foreach (var item in _context.DeclarationPages.OrderBy(x => x.SectionOrder))
            {

                var validationList = TinyMapper.Map<List<ValidationTextDTO>>(_context.ValidationTextDeclarationPages.Where(x => x.ReferenceID.ID == item.ID).ToList());
                var res = _validationParagraph(section, startIndex, item, validationList);
                startIndex = res.Item2;
                validationResult = res.Item1.ValidationResult;
                if (res.Item1.ValidationResult == false)
                {
                    validationMessage.AddRange(res.Item1.ValidationMessage);
                    return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
                }
                if (res.Item1.ValidationResult)
                {
                    validationMessage.Add($"All defined validations are clear in section \"{item.SectionName}\"");
                }
            }
            return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
        }

        private (ParagraphValidationRes, int) _validationParagraph(Section section, int startIndex, DeclarationPage declarationPage, List<ValidationTextDTO> validationText)
        {
            ParagraphValidationRes validationRes = new ParagraphValidationRes();

            if (declarationPage.SectionName.Equals("DeclarationStudentName"))
            {
                declarationPage.IsValidationText = true;
                DataClass.StudentName.ForEach(x => validationText.Add(new ValidationTextDTO() { Do = x }));
            }
            foreach (Paragraph paragraph in section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).Skip(startIndex))
            {
                GeneralClass generalClass = TinyMapper.Map<GeneralClass>(declarationPage);
                
                validationRes = _generalParagraphValidation.GetGeneralParagraphValidation(paragraph, generalClass, validationText);
                startIndex++;

                if (string.IsNullOrEmpty(declarationPage.StopLineText) || !validationRes.ValidationResult)
                {
                    break;
                }
                if (declarationPage.StopLineText.ToLower().Equals(section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).ToArray()[startIndex].Text.ToLower()))
                {
                    break;
                }
            }


            return (validationRes, startIndex);
        }
    }
}
