﻿using Nelibur.ObjectMapper;
using Spire.Doc;
using Spire.Doc.Documents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordDocumentFormatting.BusinessLayer.Common;
using WordDocumentFormatting.DataAccessLayer;
using WordDocumentFormatting.DataAccessLayer.Model;

namespace WordDocumentFormatting.BusinessLayer
{
    public interface ICertificatePageService
    {
        public (ParagraphValidationRes, int) CertificatePageValidation(Section section, int startIndex);
    }
    public class CertificatePageService:ICertificatePageService
    {
        private readonly DatabaseManager _context;
        private readonly IGeneralParagraphValidation _paragraphValidation;
        public CertificatePageService(DatabaseManager context, IGeneralParagraphValidation paragraphValidation)
        {
            _context = context;
            _paragraphValidation = paragraphValidation;
        }

        public (ParagraphValidationRes, int) CertificatePageValidation(Section section, int startIndex)
        {
            bool validationResult = true;
            List<string> validationMessage = new List<string>();
            foreach (var item in _context.CertificatePages.OrderBy(x => x.SectionOrder))
            {
                var validationList = TinyMapper.Map<List<ValidationTextDTO>>(_context.ValidationTextCertificatePages.Where(x => x.ReferenceID.ID == item.ID).ToList());
                var res = _validationParagraph(section, startIndex, item, validationList);
                //var res = _validationParagraph(section, startIndex, item);
                startIndex = res.Item2;
                if (res.Item1.ValidationResult == false)
                {
                    validationMessage.AddRange(res.Item1.ValidationMessage);
                    return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
                }
                if (res.Item1.ValidationResult)
                {
                    validationMessage.Add($"All defined validations are clear in section \"{item.SectionName}\"");
                }
            }
            return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
        }

        private (ParagraphValidationRes, int) _validationParagraph(Section section, int startIndex, CertificatePage certificatePage,List<ValidationTextDTO> validationTexts)
        {
            ParagraphValidationRes validationRes = new ParagraphValidationRes();

            foreach (Paragraph paragraph in section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).Skip(startIndex))
            {
                GeneralClass generalClass = TinyMapper.Map<GeneralClass>(certificatePage);
                validationRes = _paragraphValidation.GetGeneralParagraphValidation(paragraph, generalClass, validationTexts);
                startIndex++;

                //var daat= section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).ToArray()[startIndex].Text.ToLower();
                if (string.IsNullOrEmpty(certificatePage.StopLineText) || !validationRes.ValidationResult)
                {
                    break;
                }
                if (certificatePage.StopLineText.ToLower().Equals(section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).ToArray()[startIndex].Text.ToLower()))
                {
                    
                }
                
            }


            return (validationRes, startIndex);
        }
        
    }
}
