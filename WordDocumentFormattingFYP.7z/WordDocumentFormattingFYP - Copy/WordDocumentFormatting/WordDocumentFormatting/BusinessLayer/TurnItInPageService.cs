﻿using Nelibur.ObjectMapper;
using Spire.Doc.Documents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordDocumentFormatting.BusinessLayer.Common;
using WordDocumentFormatting.DataAccessLayer.Model;
using WordDocumentFormatting.DataAccessLayer;
using Spire.Doc;

namespace WordDocumentFormatting.BusinessLayer
{
    public interface ITurnItInPageService
    {
        public (ParagraphValidationRes, int) TurnItInPageValidation(Section section, int startIndex);
    }
    public class TurnItInPageService : ITurnItInPageService
    {
        private readonly DatabaseManager _context;
        private readonly ITurnItInParagraphValidation _paragraphValidation;
        private readonly IGeneralParagraphValidation _generalParagraphValidation;

        public TurnItInPageService(DatabaseManager context, IGeneralParagraphValidation generalParagraphValidation, ITurnItInParagraphValidation paragraphValidation)
        {
            _context = context;
            _generalParagraphValidation = generalParagraphValidation;
            _paragraphValidation = paragraphValidation;
        }

        public (ParagraphValidationRes, int) TurnItInPageValidation(Section section, int startIndex)
        {
            bool validationResult = true;
            List<string> validationMessage = new List<string>();
            foreach (var item in _context.TurnItInPages.OrderBy(x => x.SectionOrder))
            {
                
                var validationList = TinyMapper.Map<List<ValidationTextDTO>>(_context.ValidationTextTurnItInPages.Where(x => x.ReferenceID.ID == item.ID).ToList());
                var res = _validationParagraph(section, startIndex, item, validationList);
                startIndex = res.Item2;
                validationResult = res.Item1.ValidationResult;
                if (res.Item1.ValidationResult == false)
                {
                    validationMessage.AddRange(res.Item1.ValidationMessage);
                    return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
                }
                if (res.Item1.ValidationResult)
                {
                    validationMessage.Add($"All defined validations are clear in section \"{item.SectionName}\"");
                }
            }
            return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
        }

        private (ParagraphValidationRes, int) _validationParagraph(Section section, int startIndex, TurnItInPage turnItInPage, List<ValidationTextDTO> validationText)
        {
            ParagraphValidationRes validationRes = new ParagraphValidationRes();


            foreach (Paragraph paragraph in section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).Skip(startIndex))
            {
                GeneralClass generalClass = TinyMapper.Map<GeneralClass>(turnItInPage);
                
                validationRes = _generalParagraphValidation.GetGeneralParagraphValidation(paragraph, generalClass, validationText);

                if (validationRes.ValidationResult)
                {
                    validationRes = _paragraphValidation.GetTurItInParagraphValidation(paragraph, turnItInPage, validationText);
                }

                startIndex++;



                if (string.IsNullOrEmpty(turnItInPage.StopLineText) || !validationRes.ValidationResult)
                {
                    break;
                }
                if (turnItInPage.StopLineText.ToLower().Equals(section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).ToArray()[startIndex].Text.ToLower()))
                {
                    break;
                }
            }


            return (validationRes, startIndex);
        }
    }
}
