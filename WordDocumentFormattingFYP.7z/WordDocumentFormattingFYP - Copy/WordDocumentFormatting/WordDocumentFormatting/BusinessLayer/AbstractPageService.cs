﻿using Nelibur.ObjectMapper;
using Spire.Doc;
using Spire.Doc.Documents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordDocumentFormatting.BusinessLayer.Common;
using WordDocumentFormatting.DataAccessLayer;
using WordDocumentFormatting.DataAccessLayer.Model;

namespace WordDocumentFormatting.BusinessLayer
{
    public interface IAbstractPageService
    {
        public (ParagraphValidationRes, int) AbstractPageValidation(Section section, int startIndex);
    }
    public class AbstractPageService : IAbstractPageService
    {

        private readonly DatabaseManager _context;
        private readonly IGeneralParagraphValidation _paragraphValidation;
        public AbstractPageService(DatabaseManager context, IGeneralParagraphValidation paragraphValidation)
        {
            _context = context;
            _paragraphValidation = paragraphValidation;
        }

        public (ParagraphValidationRes, int) AbstractPageValidation(Section section, int startIndex)
        {
            bool validationResult = true;
            List<string> validationMessage = new List<string>();
            foreach (var item in _context.AbstractPages.OrderBy(x => x.SectionOrder))
            {
                var res = _validationParagraph(section, startIndex, item);
                startIndex = res.Item2;
                if (res.Item1.ValidationResult == false)
                {
                    validationMessage.AddRange(res.Item1.ValidationMessage);
                    return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
                }
                if (res.Item1.ValidationResult)
                {
                    validationMessage.Add($"All defined validations are clear in section \"{item.SectionName}\"");
                }
            }
            return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
        }

        private (ParagraphValidationRes, int) _validationParagraph(Section section, int startIndex, AbstractPage abstractPage)
        {
            ParagraphValidationRes validationRes = new ParagraphValidationRes();

            int paragraphCount = 0;
            int WordCount=0;
            foreach (Paragraph paragraph in section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).Skip(startIndex))
            {
                GeneralClass generalClass = TinyMapper.Map<GeneralClass>(abstractPage);
                validationRes = _paragraphValidation.GetGeneralParagraphValidation(paragraph, generalClass, new List<ValidationTextDTO>());
                startIndex++;
                
                //var daat= section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).ToArray()[startIndex].Text.ToLower();
                if (string.IsNullOrEmpty(abstractPage.StopLineText) || !validationRes.ValidationResult)
                {
                    break;
                }
                if (abstractPage.StopLineText.ToLower().Equals(section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).ToArray()[startIndex].Text.ToLower()))
                {
                    if(!(paragraphCount>=abstractPage.MinParagraph))
                    {
                        validationRes.ValidationResult = false;
                        validationRes.ValidationMessage.Add($"Minimum paragraph should be {abstractPage.MinParagraph} in section {abstractPage.SectionName}");
                    }
                    if (!(paragraphCount <= abstractPage.MaxParagraph))
                    {
                        validationRes.ValidationResult = false;
                        validationRes.ValidationMessage.Add($"Maximum paragraph should be {abstractPage.MaxParagraph} in section {abstractPage.SectionName}");
                    }
                    if (!(WordCount >= abstractPage.MinWordCount))
                    {
                        validationRes.ValidationResult = false;
                        validationRes.ValidationMessage.Add($"Minimum words should be {abstractPage.MinWordCount} in section {abstractPage.SectionName}");
                    }
                    break;
                }
                if (abstractPage.MinParagraph != 0 || abstractPage.MaxParagraph != 0)
                {
                    paragraphCount++;
                    WordCount += paragraph.WordCount;
                }
            }


            return (validationRes, startIndex);
        }
    }
}

