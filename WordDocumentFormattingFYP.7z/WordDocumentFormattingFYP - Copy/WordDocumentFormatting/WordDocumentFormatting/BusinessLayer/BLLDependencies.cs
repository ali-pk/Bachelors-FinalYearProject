﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Spire.Pdf.Interactive.DigitalSignatures;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordDocumentFormatting.BusinessLayer.Common;
using WordDocumentFormatting.DataAccessLayer;

namespace WordDocumentFormatting.BusinessLayer
{
    public static class BLLDependency
    {
        //public static void AllDependencies(IServiceCollection services, IConfiguration configuration)
        //{
        //    // Dependencies here from BLL & DAL tier.

        //    services.AddSingleton<ITitlePageService, TitlePageService>();
        //    services.AddSingleton<IParagraphValidation, ParagraphValidation>();
        //    services.AddDbContext<DatabaseManager>(builder => builder.UseSqlServer(connectionString));
        //}
    }
}
