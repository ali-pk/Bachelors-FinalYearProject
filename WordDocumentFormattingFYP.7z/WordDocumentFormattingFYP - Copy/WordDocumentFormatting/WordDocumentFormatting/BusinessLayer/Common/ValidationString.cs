﻿using Spire.Doc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.BusinessLayer.Common
{
    internal static class ValidationString
    {
        public static string FontSize = "Font size should be {value} in {section}";
        public static string FontName = "Font name should be {value} in {section}";
        public static string Bold = "Font should be {value} in {section}";
        public static string Italic = "Font should be {value} in {section}";
        public static string Image = "Documet type should be {value} in {section}";
        public static string Alignment = "Alignment should be {value} in {section}";
        public static string DocumentType = "Document type should be {value} in {section}";
        public static string ImageWidth = "Image width should be {value} in {section}";
        public static string ImageHeight = "Image height should be {value} in {section}";
        public static string TextValidation = "Text should be {value} in {section}";
        public static string DosValidation = "Text should contain {value} in {section}";
        public static string DontValidation = "Text should not contain {value} in {section}";
        public static string MustValidation = "Text should be {value} in {section}";
        public static string Caps = "Text should be {value} in {section}";
        public static string DateValidation = "Date should be {value} in {section}";
        public static string GetValidationError(this string message,object value,string section)
        {
            return message.Replace("{value}", value.ToString()).Replace("{section}", section);
        }

    }
    
    
}
