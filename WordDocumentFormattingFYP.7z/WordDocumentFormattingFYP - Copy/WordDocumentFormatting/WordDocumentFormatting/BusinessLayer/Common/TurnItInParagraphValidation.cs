﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordDocumentFormatting.DataAccessLayer.Model;
using WordDocumentFormatting.DataAccessLayer;
using Spire.Doc.Documents;

namespace WordDocumentFormatting.BusinessLayer.Common
{
    public interface ITurnItInParagraphValidation
    {
        public ParagraphValidationRes GetTurItInParagraphValidation(Paragraph paragraph, TurnItInPage validationModel, List<ValidationTextDTO> validationText);
    }

    public class TurnItInParagraphValidation : ITurnItInParagraphValidation
    {
        private readonly DatabaseManager _context;
        public TurnItInParagraphValidation(DatabaseManager context)
        {
            _context = context;
        }
        public ParagraphValidationRes GetTurItInParagraphValidation(Paragraph paragraph, TurnItInPage validationModel, List<ValidationTextDTO> validationText)
        {
            bool validationResult = true;
            List<string> validationErrors = new List<string>();
            var format = paragraph.BreakCharacterFormat;
            if (!validationModel.IsImage)
            {

                if (!string.IsNullOrEmpty(validationModel.DateValidation))
                {
                    var paragraphText = paragraph.Text;
                    var replaceListText = validationText.Where(x => !string.IsNullOrEmpty(x.Replace)).Select(x => x.Replace).ToList();
                    if (replaceListText.Count > 0)
                    {
                        replaceListText.ForEach(x => { paragraphText = paragraphText.Replace(x, ""); });
                        paragraphText = paragraphText.TrimStart().TrimEnd();
                    }

                    var res = CommonFunctions.GetIfDateFormatIsCorrect(validationModel.DateValidation, paragraphText);
                    if (!res)
                    {
                        validationErrors.Add(ValidationString.DateValidation.GetValidationError(validationModel.DateValidation, validationModel.SectionName));
                        validationResult = false;
                    }
                }


            }


            if (!validationResult)
            {
                paragraph.Format.BackColor = Color.Red;
                format.TextBackgroundColor = Color.Red;
            }
            return new ParagraphValidationRes() { ValidationMessage = validationErrors, ValidationResult = validationResult };
        }
    }
}
