﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.BusinessLayer.Common
{
    public static class DataClass
    {
        public static List<string> StudentName;
    }
}
