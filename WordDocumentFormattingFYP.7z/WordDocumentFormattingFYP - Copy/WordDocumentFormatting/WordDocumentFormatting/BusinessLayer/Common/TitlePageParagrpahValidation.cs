﻿using Spire.Doc.Documents;
using Spire.Doc.Fields;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WordDocumentFormatting.DataAccessLayer;
using WordDocumentFormatting.DataAccessLayer.Model;

namespace WordDocumentFormatting.BusinessLayer.Common
{
    public interface ITitlePageParagraphValidation
    {
        public ParagraphValidationRes GetTitlePageParagraphValidation(Paragraph paragraph, TitlePage validationModel);
    }

    public class TitlePageParagraphValidation : ITitlePageParagraphValidation
    {
        private readonly DatabaseManager _context;
        public TitlePageParagraphValidation(DatabaseManager context)
        {
            _context = context;
        }
        public ParagraphValidationRes GetTitlePageParagraphValidation(Paragraph paragraph, TitlePage validationModel)
        {
            bool validationResult = true;
            List<string> validationErrors = new List<string>();
            var format = paragraph.BreakCharacterFormat;
            if (!validationModel.IsImage)
            {
                if (!string.IsNullOrEmpty(validationModel.DateValidation))
                {
                    var res = CommonFunctions.GetIfDateFormatIsCorrect(validationModel.DateValidation, paragraph.Text);
                    if (!res)
                    {
                        validationErrors.Add(ValidationString.DateValidation.GetValidationError(validationModel.DateValidation, validationModel.SectionName));
                        validationResult = false;
                    }
                }


            }


            if (!validationResult)
            {
                paragraph.Format.BackColor = Color.Red;
                format.TextBackgroundColor = Color.Red;
            }
            return new ParagraphValidationRes() { ValidationMessage = validationErrors, ValidationResult = validationResult };
        }
    }
}
