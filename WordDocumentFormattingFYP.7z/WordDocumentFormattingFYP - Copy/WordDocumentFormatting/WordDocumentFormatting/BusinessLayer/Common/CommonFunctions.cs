﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.BusinessLayer.Common
{
    public class CommonFunctions
    {
        public static bool GetIfDateFormatIsCorrect(string dateValidation,string date)
        {
            DateTime dateValue;

            bool res = DateTime.TryParseExact(date, new String[] { dateValidation },
                                            new CultureInfo("en-US"),
                                            DateTimeStyles.None,
                                            out dateValue);
            return res;
        }
    }
}
