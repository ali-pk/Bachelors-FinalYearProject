﻿using Spire.Doc.Documents;
using Spire.Doc.Fields;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WordDocumentFormatting.DataAccessLayer;
using WordDocumentFormatting.DataAccessLayer.Model;

namespace WordDocumentFormatting.BusinessLayer.Common
{
    public interface IGeneralParagraphValidation
    {
        public ParagraphValidationRes GetGeneralParagraphValidation(Paragraph paragraph, GeneralClass validationModel,List<ValidationTextDTO> validationText);
    }
    public class GeneralParagraphValidation: IGeneralParagraphValidation
    {
        private readonly DatabaseManager _context;
        public GeneralParagraphValidation(DatabaseManager context)
        {
            _context = context;
        }
        public ParagraphValidationRes GetGeneralParagraphValidation(Paragraph paragraph, GeneralClass validationModel, List<ValidationTextDTO> validationText)
        {
            bool validationResult = true;
            List<string> validationErrors = new List<string>();
            var format = paragraph.BreakCharacterFormat;
            if (!validationModel.IsImage)
            {
                //if (paragraph.FirstChild != null && (paragraph.FirstChild.DocumentObjectType != DocumentObjectType.TextRange || paragraph.FirstChild.DocumentObjectType!=DocumentObjectType.FieldMark))
                //{
                //    validationErrors.Add(ValidationString.DocumentType.GetValidationError("text range", validationModel.SectionName));
                //    validationResult = false;
                //}
                if (!format.FontName.Equals(validationModel.FontStyle))
                {
                    validationErrors.Add(ValidationString.FontName.GetValidationError(validationModel.FontStyle, validationModel.SectionName));
                    validationResult = false;
                }
                if (!format.FontSize.Equals(validationModel.FontSize))
                {
                    validationErrors.Add(ValidationString.FontSize.GetValidationError(validationModel.FontSize, validationModel.SectionName));
                    validationResult = false;
                }
                if (!format.Bold == validationModel.IsBold)
                {
                    validationErrors.Add(ValidationString.Bold.GetValidationError("bold", validationModel.SectionName));
                    validationResult = false;
                }
                if (!format.Italic == validationModel.IsItalic)
                {
                    validationErrors.Add(ValidationString.Italic.GetValidationError("italic", validationModel.SectionName));
                    validationResult = false;
                }
                if (string.IsNullOrEmpty(paragraph.Text) && paragraph.FirstChild != null && paragraph.FirstChild.DocumentObjectType != DocumentObjectType.TextRange)
                {
                    validationErrors.Add(ValidationString.DocumentType.GetValidationError("non empty/designated text", validationModel.SectionName));
                    validationResult = false;
                }
                if (!string.IsNullOrEmpty(validationModel.TextValidation))
                {
                    var paragraphText = paragraph.Text;
                    var replaceListText = validationText.Where(x => !string.IsNullOrEmpty(x.Replace)).Select(x => x.Replace).ToList();
                    if(replaceListText.Count>0)
                    {
                        replaceListText.ForEach(x => { paragraphText = paragraphText.Replace(x, ""); });
                        //paragraphText.TrimStart().TrimEnd();
                    }
                    paragraphText=paragraphText.TrimStart().TrimEnd();
                    if (!validationModel.TextValidation.Equals(paragraphText))
                    {
                        validationErrors.Add(ValidationString.TextValidation.GetValidationError(validationModel.TextValidation, validationModel.SectionName));
                        validationResult = false;
                    }
                }
                if (!string.IsNullOrEmpty(validationModel.Regex))
                {
                    var paragraphText = paragraph.Text;
                    var replaceListText = validationText.Where(x => !string.IsNullOrEmpty(x.Replace)).Select(x => x.Replace).ToList();
                    if (replaceListText.Count > 0)
                    {
                        replaceListText.ForEach(x => { paragraphText = paragraphText.Replace(x, ""); });
                        paragraphText = paragraphText.TrimStart().TrimEnd();
                    }

                    var validation = new Regex(validationModel.Regex);
                    if (!validation.IsMatch(paragraphText))
                    {
                        validationErrors.Add("Every word in {section} section must be {value}".GetValidationError("starts with capital letter and next letter should in lower", validationModel.SectionName));
                        validationResult = false;
                    }
                }
                if(validationModel.IsCaps)
                {
                    var isCaps = true;
                    paragraph.Text.Trim().ToCharArray().ToList().ForEach(x => { if (!Char.IsUpper(x) && !x.Equals(' ')) { isCaps = false; return; } });
                    if(!isCaps)
                    {
                        validationErrors.Add(ValidationString.Caps.GetValidationError("in CAPS", validationModel.SectionName));
                        validationResult = false;
                    }
                    

                }
                if (validationModel.IsValidationText)
                {
                    
                    var dosValidationText = validationText.Where(x => !string.IsNullOrEmpty(x.Do)).Select(x => x.Do).ToList();
                    var dontValidationText = validationText.Where(x => !string.IsNullOrEmpty(x.Dont)).Select(x => x.Dont).ToList();
                    var mustValidationText = validationText.Where(x => !string.IsNullOrEmpty(x.Must)).Select(x => x.Must).ToList();
                    if (dosValidationText.Count > 0)
                    {
                        if (!dosValidationText.Any(x => paragraph.Text.Contains(x + " ")))
                        {
                            validationErrors.Add(ValidationString.DosValidation.GetValidationError(string.Join(",", dosValidationText), validationModel.SectionName));
                            validationResult = false;
                        }

                    }
                    if (dontValidationText.Count > 0)
                    {
                        if (dontValidationText.Any(x => paragraph.Text.Contains(x + " ")))
                        {
                            validationErrors.Add(ValidationString.DontValidation.GetValidationError(string.Join(",", dontValidationText), validationModel.SectionName));
                            validationResult = false;
                        }

                    }

                }

            }
            else
            {
                if (paragraph.FirstChild != null && paragraph.FirstChild.DocumentObjectType == DocumentObjectType.Picture)
                {
                    var shapeObject = paragraph.FirstChild as ShapeObject;
                    if (shapeObject != null)
                    {
                        if (!(Convert.ToInt32(shapeObject.Width) >= validationModel.ImageWidth))
                        {
                            validationErrors.Add(ValidationString.ImageWidth.GetValidationError(validationModel.ImageWidth, validationModel.SectionName));
                            validationResult = false;
                        }
                        if (!(Convert.ToInt32(shapeObject.Height) >= validationModel.ImageHeight))
                        {
                            validationErrors.Add(ValidationString.ImageHeight.GetValidationError(validationModel.ImageHeight, validationModel.SectionName));
                            validationResult = false;
                        }
                    }

                }
                else
                {
                    validationErrors.Add(ValidationString.DocumentType.GetValidationError("image", validationModel.SectionName));
                    validationResult = false;
                }
            }

            if (!paragraph.Format.HorizontalAlignment.ToString().Equals(validationModel.ParagrphAlignment))
            {
                validationErrors.Add(ValidationString.Alignment.GetValidationError(validationModel.ParagrphAlignment, validationModel.SectionName));
                validationResult = false;
            }


            if (!validationResult)
            {
                paragraph.Format.BackColor = Color.Red;
                format.TextBackgroundColor = Color.Red;
            }
            return new ParagraphValidationRes() { ValidationMessage = validationErrors, ValidationResult = validationResult };
        }
    }
}
