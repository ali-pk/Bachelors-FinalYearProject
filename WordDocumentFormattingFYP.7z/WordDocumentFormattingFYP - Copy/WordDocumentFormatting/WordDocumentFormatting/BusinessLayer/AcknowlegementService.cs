﻿using Nelibur.ObjectMapper;
using Spire.Doc.Documents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordDocumentFormatting.BusinessLayer.Common;
using WordDocumentFormatting.DataAccessLayer.Model;
using WordDocumentFormatting.DataAccessLayer;
using Spire.Doc;

namespace WordDocumentFormatting.BusinessLayer
{

    public interface IAcknowlegementService
    {
        public (ParagraphValidationRes, int) AcknowledgementPageValidation(Section section, int startIndex);
    }
    public class AcknowlegementService : IAcknowlegementService
    {
        private readonly DatabaseManager _context;
        private readonly IGeneralParagraphValidation _paragraphValidation;
        public AcknowlegementService(DatabaseManager context, IGeneralParagraphValidation paragraphValidation)
        {
            _context = context;
            _paragraphValidation = paragraphValidation;
        }

        public (ParagraphValidationRes, int) AcknowledgementPageValidation(Section section, int startIndex)
        {
            bool validationResult = true;
            List<string> validationMessage = new List<string>();
            foreach (var item in _context.AcknowledgementPages.OrderBy(x => x.SectionOrder))
            {
                var res = _validationParagraph(section, startIndex, item);
                startIndex = res.Item2;
                if (res.Item1.ValidationResult == false)
                {
                    validationMessage.AddRange(res.Item1.ValidationMessage);
                    return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
                }
                if (res.Item1.ValidationResult)
                {
                    validationMessage.Add($"All defined validations are clear in section \"{item.SectionName}\"");
                }
            }
            return (new ParagraphValidationRes() { ValidationMessage = validationMessage, ValidationResult = validationResult }, startIndex);
        }

        private (ParagraphValidationRes, int) _validationParagraph(Section section, int startIndex, AcknowledgementPage acknowledgementPage)
        {
            ParagraphValidationRes validationRes = new ParagraphValidationRes();
            
            foreach (Paragraph paragraph in section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).Skip(startIndex))
            {
                GeneralClass generalClass = TinyMapper.Map<GeneralClass>(acknowledgementPage);
                validationRes = _paragraphValidation.GetGeneralParagraphValidation(paragraph, generalClass, new List<ValidationTextDTO>());
                startIndex++;

                //var daat= section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).ToArray()[startIndex].Text.ToLower();
                if (string.IsNullOrEmpty(acknowledgementPage.StopLineText) || !validationRes.ValidationResult)
                {
                    break;
                }
                if (acknowledgementPage.StopLineText.ToLower().Equals(section.Paragraphs.Cast<Paragraph>().Where(x => x.FirstChild != null && (!string.IsNullOrEmpty(x.Text) || x.FirstChild.DocumentObjectType == DocumentObjectType.Picture)).ToArray()[startIndex].Text.ToLower()))
                {
                    
                    break;
                }
                
            }

            return (validationRes, startIndex);
        }
    }
}
