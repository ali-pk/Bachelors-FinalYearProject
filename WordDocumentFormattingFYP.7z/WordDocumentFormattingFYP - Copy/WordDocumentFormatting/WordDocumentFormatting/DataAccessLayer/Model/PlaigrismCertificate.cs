﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.DataAccessLayer.Model
{
    public class PlaigrismCertificate:GeneralClass
    {
        public string DateValidation { get; set; } = "";
    }
    public class ValidationTextPlaigrismCertificate
    {
        
            [Key]
            public int ID { get; set; }

            public virtual PlaigrismCertificate ReferenceID { get; set; }

            public string Do { get; set; } = "";
            public string Dont { get; set; } = "";
            public string Must { get; set; } = "";
            public string Can { get; set; } = "";
            public string Replace { get; set; } = "";
        
    }
}
