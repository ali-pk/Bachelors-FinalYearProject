﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.DataAccessLayer.Model
{
    public class DeclarationPage:GeneralClass
    {
    }

    public class ValidationTextDeclarationPage
    {
        [Key]
        public int ID { get; set; }

        public virtual DeclarationPage ReferenceID { get; set; }

        public string Do { get; set; } = "";
        public string Dont { get; set; } = "";
        public string Must { get; set; } = "";
        public string Can { get; set; } = "";
    }
}
