﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.DataAccessLayer.Model
{
    public class CertificatePage:GeneralClass
    {
    }
    public class ValidationTextCertificatePage
    {
        [Key]
        public int ID { get; set; }

        public virtual CertificatePage ReferenceID { get; set; }

        public string Do { get; set; } = "";
        public string Dont { get; set; } = "";
        public string Must { get; set; } = "";
        public string Can { get; set; } = "";
    }
}
