﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.DataAccessLayer.Model
{
    public static class ListOfFigures
    {
        public static List<string> FiguresList { get; set; } = new List<string>();
    }
    public static class ListOfTables
    {
        public static List<string> TablesList { get; set; } = new List<string>();
    }
    public static class TableOfContent
    {
        public static List<Chapter> Chapters { get; set; }
    }
    public class Chapter
    {
        public string ChapterTitle { get; set; } = "";
        public string ChapterName { get; set; } = "";

        public string PageNo { get; set; } = "";
        public string ChapterNo { get; set; } = "";
        public List<ChapterHeading> Headings = new List<ChapterHeading>();
        

    }
    public class ChapterHeading
    {
        public string HeadingTitle { get; set; }="";
        public string HeadingName { get; set; } = "";
        public string PageNo { get; set; } = "";
        public string Version { get; set; } = "";
        //public List<ChapterSubHeading> SubHeadings=new List<ChapterSubHeading>();
    }
    public class ChapterSubHeading
    {
        public Version Version{ get; set; }= new Version();
        public string SubHeadingName { get; set; } = "";
        public int PageNo { get; set; } = 0;
    }

    public class HeadingWithChapterNo
    {
        public string VersionNo { get; set; }
        public string ChapterNo { get; set; }
    }
}
