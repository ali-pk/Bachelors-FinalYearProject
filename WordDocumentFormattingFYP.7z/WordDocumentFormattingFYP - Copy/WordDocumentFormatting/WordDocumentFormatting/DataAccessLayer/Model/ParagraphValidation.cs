﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.DataAccessLayer.Model
{
    public class ParagraphValidationRes
    {
        public bool ValidationResult { get; set; }
        public List<string> ValidationMessage { get; set; }=new List<string>();

    }
}
