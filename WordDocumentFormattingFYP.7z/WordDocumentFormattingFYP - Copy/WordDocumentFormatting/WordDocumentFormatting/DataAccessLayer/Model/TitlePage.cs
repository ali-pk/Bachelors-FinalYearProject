﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.DataAccessLayer.Model
{
    public class GeneralClass
    {
        [Key]
        public int ID { get; set; }
        public float FontSize { get; set; }
        public string FontStyle { get; set; } = "";
        public bool IsBold { get; set; }
        public bool IsItalic { get; set; }
        public bool IsImage { get; set; }
        public string TextValidation { get; set; } = "";
        public int ImageWidth { get; set; }
        public int ImageHeight { get; set; }
        public string SectionName { get; set; } = "";
        public int SectionOrder { get; set; }
        public string ParagrphAlignment { get; set; } = "";
        public bool IsValidationText { get; set; }
        public string StopLineText { get; set; } = "";
        
        public string Regex { get; set; } = "";
        public bool IsCaps { get; set; }
    }

    public class TitlePage:GeneralClass
    {
        public string DateValidation { get; set; } = "";
    }
    public class ValidationText
    {
        [Key]
        public int ID { get; set; }
        
        public virtual TitlePage ReferenceID { get; set; }
        
        public string Do { get; set; } = "";
        public string Dont { get; set; } = "";
        public string Must { get; set; } = "";
        public string Can { get; set; } = "";
        public string Replace { get; set; } = "";
    }

    public class ValidationTextDTO
    {
        public int ID { get; set; }

        public int ReferenceID { get; set; }

        public string Do { get; set; } = "";
        public string Dont { get; set; } = "";
        public string Must { get; set; } = "";
        public string Can { get; set; } = "";
        public string Replace { get; set; } = "";
    }



}
