﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDocumentFormatting.DataAccessLayer.Model
{

    public class AbstractPage : GeneralClass
    {
        public int MinWordCount { get; set; }
        public int MaxParagraph { get; set; }
        public int MinParagraph { get; set; }
    }


}
