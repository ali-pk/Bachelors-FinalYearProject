﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordDocumentFormatting.DataAccessLayer.Model;

namespace WordDocumentFormatting.DataAccessLayer
{
    public class DatabaseManager:DbContext
    {
        public DatabaseManager(DbContextOptions options) : base(options)
        {
        }
        public DbSet<TitlePage> TitlePages { get; set; } 
        public DbSet<ValidationText> ValidationText { get; set; }
        public DbSet<AbstractPage> AbstractPages { get; set; }
        public DbSet<CertificatePage> CertificatePages { get; set; }
        public DbSet<ValidationTextCertificatePage> ValidationTextCertificatePages { get; set; }
        public DbSet<DeclarationPage> DeclarationPages { get; set; }
        public DbSet<ValidationTextDeclarationPage> ValidationTextDeclarationPages { get; set; }
        public DbSet<PlaigrismCertificate> PlaigrismCertificates { get; set; }
        public DbSet<ValidationTextPlaigrismCertificate> ValidationTextPlaigrismCertificates { get; set; }
        public DbSet<ValidationTextTurnItInPage> ValidationTextTurnItInPages { get; set; }
        public DbSet<TurnItInPage> TurnItInPages { get; set; }
        public DbSet<AcknowledgementPage> AcknowledgementPages { get; set; }
    }
}
