﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WordDocumentFormatting.Migrations.initial
{
    /// <inheritdoc />
    public partial class NewUpdatesAbstractTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Discriminator",
                table: "TitlePages");

            migrationBuilder.DropColumn(
                name: "MaxParagraph",
                table: "TitlePages");

            migrationBuilder.DropColumn(
                name: "MinParagraph",
                table: "TitlePages");

            migrationBuilder.DropColumn(
                name: "MinWordCount",
                table: "TitlePages");

            migrationBuilder.DropColumn(
                name: "NoOfPages",
                table: "TitlePages");

            migrationBuilder.CreateTable(
                name: "AbstractPages",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MinWordCount = table.Column<int>(type: "int", nullable: false),
                    MaxParagraph = table.Column<int>(type: "int", nullable: false),
                    MinParagraph = table.Column<int>(type: "int", nullable: false),
                    NoOfPages = table.Column<int>(type: "int", nullable: false),
                    FontSize = table.Column<float>(type: "real", nullable: false),
                    FontStyle = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsBold = table.Column<bool>(type: "bit", nullable: false),
                    IsItalic = table.Column<bool>(type: "bit", nullable: false),
                    IsImage = table.Column<bool>(type: "bit", nullable: false),
                    TextValidation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ImageWidth = table.Column<int>(type: "int", nullable: false),
                    ImageHeight = table.Column<int>(type: "int", nullable: false),
                    SectionName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SectionOrder = table.Column<int>(type: "int", nullable: false),
                    ParagrphAlignment = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsValidationText = table.Column<bool>(type: "bit", nullable: false),
                    StopLineText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Regex = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsCaps = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AbstractPages", x => x.ID);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AbstractPages");

            migrationBuilder.AddColumn<string>(
                name: "Discriminator",
                table: "TitlePages",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "MaxParagraph",
                table: "TitlePages",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MinParagraph",
                table: "TitlePages",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MinWordCount",
                table: "TitlePages",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "NoOfPages",
                table: "TitlePages",
                type: "int",
                nullable: true);
        }
    }
}
