﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WordDocumentFormatting.Migrations.initial
{
    /// <inheritdoc />
    public partial class ValidationTextAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsValidationText",
                table: "TitlePages",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "ValidationText",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReferenceIDID = table.Column<int>(type: "int", nullable: false),
                    Do = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Dont = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Must = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValidationText", x => x.ID);
                    table.ForeignKey(
                        name: "FK_ValidationText_TitlePages_ReferenceIDID",
                        column: x => x.ReferenceIDID,
                        principalTable: "TitlePages",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ValidationText_ReferenceIDID",
                table: "ValidationText",
                column: "ReferenceIDID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ValidationText");

            migrationBuilder.DropColumn(
                name: "IsValidationText",
                table: "TitlePages");
        }
    }
}
