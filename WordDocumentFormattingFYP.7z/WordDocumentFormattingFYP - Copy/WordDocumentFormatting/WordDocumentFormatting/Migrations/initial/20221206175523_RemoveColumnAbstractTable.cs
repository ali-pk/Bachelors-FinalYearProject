﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WordDocumentFormatting.Migrations.initial
{
    /// <inheritdoc />
    public partial class RemoveColumnAbstractTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NoOfPages",
                table: "AbstractPages");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "NoOfPages",
                table: "AbstractPages",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
