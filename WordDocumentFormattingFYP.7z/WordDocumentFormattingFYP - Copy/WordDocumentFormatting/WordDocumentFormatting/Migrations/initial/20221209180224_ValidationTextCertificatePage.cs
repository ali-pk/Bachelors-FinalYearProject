﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WordDocumentFormatting.Migrations.initial
{
    /// <inheritdoc />
    public partial class ValidationTextCertificatePage : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ValidationTextCertificatePages",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReferenceIDID = table.Column<int>(type: "int", nullable: false),
                    Do = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Dont = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Must = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Can = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValidationTextCertificatePages", x => x.ID);
                    table.ForeignKey(
                        name: "FK_ValidationTextCertificatePages_CertificatePages_ReferenceIDID",
                        column: x => x.ReferenceIDID,
                        principalTable: "CertificatePages",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ValidationTextCertificatePages_ReferenceIDID",
                table: "ValidationTextCertificatePages",
                column: "ReferenceIDID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ValidationTextCertificatePages");
        }
    }
}
