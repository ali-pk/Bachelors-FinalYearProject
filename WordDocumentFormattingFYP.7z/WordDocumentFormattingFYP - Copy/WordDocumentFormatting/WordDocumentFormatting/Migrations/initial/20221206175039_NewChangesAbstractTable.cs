﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WordDocumentFormatting.Migrations.initial
{
    /// <inheritdoc />
    public partial class NewChangesAbstractTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "NoOfPages",
                table: "TitlePages",
                type: "int",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NoOfPages",
                table: "TitlePages");
        }
    }
}
