﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WordDocumentFormatting.Migrations.initial
{
    /// <inheritdoc />
    public partial class AddedValidationTextPlaigrismCertificateV1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ValidationTextPlaigrismCertificates",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReferenceIDID = table.Column<int>(type: "int", nullable: false),
                    Do = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Dont = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Must = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Can = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Replace = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValidationTextPlaigrismCertificates", x => x.ID);
                    table.ForeignKey(
                        name: "FK_ValidationTextPlaigrismCertificates_PlaigrismCertificates_ReferenceIDID",
                        column: x => x.ReferenceIDID,
                        principalTable: "PlaigrismCertificates",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ValidationTextPlaigrismCertificates_ReferenceIDID",
                table: "ValidationTextPlaigrismCertificates",
                column: "ReferenceIDID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ValidationTextPlaigrismCertificates");
        }
    }
}
