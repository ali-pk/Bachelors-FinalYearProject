﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WordDocumentWEB.Models
{
    public class MemberModel
    {
        //To change label title value  
        [DisplayName("Student Name")]
        public string Name { get; set; }

        //To change label title value  
        [DisplayName("Telephone / Mobile Number")]
        [Phone]
        public string PhoneNumber { get; set; }
        [DisplayName("Email")]
        [EmailAddress]
        public string Email { get; set; }

        //To change label title value  
        [DisplayName("Upload Word File")]
        
        public string ImagePath { get; set; }

        public IFormFile ImageFile { get; set; }
    }
}
