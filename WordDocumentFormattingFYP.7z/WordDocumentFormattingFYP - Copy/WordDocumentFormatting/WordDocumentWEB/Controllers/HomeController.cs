﻿using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Mvc;
using Spire.Doc;
using Spire.Doc.Formatting;
using System.Diagnostics;
using System.Net;
using WordDocumentFormatting.BusinessLayer;
using WordDocumentWEB.Models;
using System;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using Microsoft.IdentityModel.Tokens;

namespace WordDocumentWEB.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IManagementLayer _management;

        public HomeController(ILogger<HomeController> logger, IManagementLayer management)
        {
            _logger = logger;
            _management = management;
        }

        public IActionResult Index()
        {
            return View(new WordDocumentWEB.Models.MemberModel());
        }
        [HttpPost]
        public async Task<ActionResult> ContactForm(MemberModel membervalues)
        {
            
            //Use Namespace called :  System.IO  
            string FileName = Path.GetFileNameWithoutExtension(membervalues.ImageFile.FileName);

            //To Get File Extension  
            string FileExtension = Path.GetExtension(membervalues.ImageFile.FileName);

            if (!FileExtension.Contains(".doc"))
            {
                return Json(new { Status = false, StatusCode = 400, StatusMessage = "File should be word file." }); ;
            }

            var result = await UploadFile("FileToProcess", membervalues.ImageFile);

            if (!string.IsNullOrEmpty(result))
            {
                var lineNumber = 1;
                Document document = new Document();
                document.LoadFromFile(result);
                var validationResult = _management.ManageSections(document.Sections);
                var validationMessages = validationResult.Item1;
                var chapterValidationMessage = validationResult.Item2;
                var appendicesValidationMessage = validationResult.Item3;
                var referencesValidationMessage = validationResult.Item4;
                var processedFile = await UploadProcessedFile("ProcessedFiles", document, FileExtension);

                //  break;
                //}

                string validationMessageTextFile = "------------ Basic Validation Messages -------------" + "\n"
                 + string.Join("\n", validationMessages.ToArray())
                 + "\n" + "------------ Chapter Validation Messages -------------" + "\n"
                 + string.Join("\n", chapterValidationMessage.ToArray())
                 + "\n" + "------------ Appendix Validation Messages -------------" + "\n" +
                 string.Join("\n", appendicesValidationMessage.ToArray())
                 + "\n" + "------------ References Validation Messages -------------" + "\n" +
                 string.Join("\n", referencesValidationMessage.ToArray());

                //Console.WriteLine("------------ Basic Validation Messages -------------");
                //validationMessages.ForEach(x => { Console.WriteLine(lineNumber + ". " + x); lineNumber++; });
                //Console.WriteLine("\n");
                //Console.WriteLine("------------ Chapter Validation Messages -------------");
                //chapterValidationMessage.ForEach(x => { Console.WriteLine(lineNumber + ". " + x); lineNumber++; });
                //Console.WriteLine("\n");
                //Console.WriteLine("------------ Appendix Validation Messages -------------");
                //appendicesValidationMessage.ForEach(x => { Console.WriteLine(lineNumber + ". " + x); lineNumber++; });
                //Console.WriteLine("\n");
                //Console.WriteLine("------------ References Validation Messages -------------");
                //referencesValidationMessage.ForEach(x => { Console.WriteLine(lineNumber + ". " + x); lineNumber++; });
                string textfile = await UploadValidationFile(validationMessageTextFile);

                await SendEmail(membervalues.Email, new List<string>() {textfile,processedFile}, "Document validation report",$"Dear {membervalues.Name}, Please find attached validation report. Thanks!");
                return Json(new { Status = true, StatusCode = 200, StatusMessage = "Please check your email for validated files or download them from below", TextFile = textfile, processedFile = processedFile }); ;
            }
            else
            {
                return Json(new { Status = false, StatusCode = 400, StatusMessage = "Encounter error in processing file." }); ;
            }
            //To copy and save file into server.  
            //membervalues.ImageFile.SaveAs(membervalues.ImagePath);



            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [NonAction]
        public async Task<string> UploadFile(string folder, IFormFile file)
        {
            var extension = "." + file.FileName.Split('.')[file.FileName.Split('.').Length - 1];
            var filename = Guid.NewGuid().ToString() + extension;
            var path = Path.Combine(Directory.GetCurrentDirectory(), folder);
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            var completePath = Path.Combine(path, filename);

            using (var stream = new FileStream(completePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            return $"{folder}/{filename}";
        }
        [NonAction]
        public async Task<string> UploadProcessedFile(string folder, Document document, string fileExtension)
        {
            var filename = Guid.NewGuid().ToString() + fileExtension;
            var path = Path.Combine(Directory.GetCurrentDirectory(), folder);
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            var completePath = Path.Combine(path, filename);
            document.SaveToFile(completePath);
            return $"{folder}/{filename}";

        }
        [NonAction]
        public async Task<string> UploadValidationFile(string validationMessage)
        {
            var folder = "ValidationMessageFiles";
            var filename = Guid.NewGuid().ToString() + ".txt";
            var path = Path.Combine(Directory.GetCurrentDirectory(), folder);
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            var completePath = Path.Combine(path, filename);
            if (System.IO.File.Exists(completePath))
            {
                System.IO.File.Delete(completePath);
            }

            // Create a new file     
            using (StreamWriter sw = System.IO.File.CreateText(completePath))
            {
                sw.WriteLine(validationMessage);

            }

            return $"{folder}/{filename}";

        }
        [NonAction]
        public async Task<string> SendEmail(string email, List<string> attachment, string subject,string body)
        {
            try
            {
                string MailText = body;
                MailMessage message = new MailMessage();
                AlternateView view = AlternateView.CreateAlternateViewFromString(MailText, null, MediaTypeNames.Text.Html);


                message.From = new MailAddress("demoworddocument@gmail.com");
                message.To.Add(new MailAddress(email));
                foreach (var item in attachment)
                {
                    Attachment attachmentEmail;
                    attachmentEmail = new Attachment(item);
                    message.Attachments.Add(attachmentEmail);
                }



                message.Subject = subject;


                message.IsBodyHtml = true; //to make message body as html  
                message.AlternateViews.Add(view);

                var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
/*                    Credentials = new NetworkCredential("demoworddocument@gmail.com", "audktufqmpmpaohe"),*/
                    Credentials = new NetworkCredential("i.khan66aa@gmail.com", "uselzuicmatzblyi"),
                    EnableSsl = true,
                    UseDefaultCredentials = false

                };
                smtpClient.Send(message);
                return "0";
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}